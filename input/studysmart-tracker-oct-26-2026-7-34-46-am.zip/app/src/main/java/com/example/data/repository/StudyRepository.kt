package com.example.data.repository

import com.example.data.local.ChapterDao
import com.example.data.local.NeetMockTestDao
import com.example.data.local.QuestionDao
import com.example.data.local.StudyLogDao
import com.example.data.local.StudyTaskDao
import com.example.data.model.Chapter
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionMistake
import com.example.data.model.ReviewStatus
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask
import kotlinx.coroutines.flow.Flow

class StudyRepository(
    private val questionDao: QuestionDao,
    private val studyTaskDao: StudyTaskDao,
    private val studyLogDao: StudyLogDao,
    private val chapterDao: ChapterDao,
    private val neetMockTestDao: NeetMockTestDao
) {
    val allMistakes: Flow<List<QuestionMistake>> = questionDao.getAllMistakes()
    val allTasks: Flow<List<StudyTask>> = studyTaskDao.getAllTasks()
    val allLogs: Flow<List<StudyLog>> = studyLogDao.getAllLogs()
    val totalStudyMinutes: Flow<Int?> = studyLogDao.getTotalStudyMinutes()
    val allChapters: Flow<List<Chapter>> = chapterDao.getAllChapters()
    val allNeetTestsAsc: Flow<List<NeetMockTest>> = neetMockTestDao.getAllTestsAsc()
    val allNeetTestsDesc: Flow<List<NeetMockTest>> = neetMockTestDao.getAllTestsDesc()

    fun getChaptersForSubject(subject: String): Flow<List<Chapter>> =
        chapterDao.getChaptersForSubject(subject)

    suspend fun insertChapter(chapter: Chapter): Long = chapterDao.insertChapter(chapter)

    suspend fun updateChapterPriority(id: Long, priority: Int) = chapterDao.updateChapterPriority(id, priority)

    suspend fun updateChapter(chapter: Chapter) = chapterDao.updateChapter(chapter)

    suspend fun deleteChapter(id: Long) = chapterDao.deleteChapterById(id)

    suspend fun insertMistake(mistake: QuestionMistake): Long = questionDao.insertMistake(mistake)

    suspend fun updateMistake(mistake: QuestionMistake) = questionDao.updateMistake(mistake)

    suspend fun deleteMistake(id: Long) = questionDao.deleteMistakeById(id)

    suspend fun insertTask(task: StudyTask): Long = studyTaskDao.insertTask(task)

    suspend fun updateTask(task: StudyTask) = studyTaskDao.updateTask(task)

    suspend fun deleteTask(id: Long) = studyTaskDao.deleteTaskById(id)

    suspend fun insertLog(log: StudyLog): Long = studyLogDao.insertLog(log)

    suspend fun insertNeetTest(test: NeetMockTest): Long = neetMockTestDao.insertTest(test)

    suspend fun deleteNeetTest(id: Long) = neetMockTestDao.deleteTestById(id)

    fun getQuestionsDueForReview(cutoffTime: Long): Flow<List<QuestionMistake>> =
        questionDao.getQuestionsDueForReview(cutoffTime)

    suspend fun recordReviewResult(mistake: QuestionMistake, gotItRight: Boolean) {
        val newCount = mistake.reviewCount + 1
        val newMastery = if (gotItRight) {
            (mistake.masteryScore + 35).coerceAtMost(100)
        } else {
            (mistake.masteryScore - 15).coerceAtLeast(0)
        }

        val newStatus = when {
            newMastery >= 90 -> ReviewStatus.MASTERED.name
            newMastery >= 40 -> ReviewStatus.IN_PROGRESS.name
            else -> ReviewStatus.NEEDS_REVIEW.name
        }

        // Spaced repetition interval based on performance
        val daysToAdd = if (gotItRight) {
            when {
                newCount <= 1 -> 1
                newCount == 2 -> 3
                newCount == 3 -> 7
                else -> 14
            }
        } else {
            1
        }

        val nextReview = System.currentTimeMillis() + (daysToAdd * 24L * 60 * 60 * 1000)

        updateMistake(
            mistake.copy(
                reviewCount = newCount,
                masteryScore = newMastery,
                status = newStatus,
                nextReviewDate = nextReview
            )
        )
    }
}
