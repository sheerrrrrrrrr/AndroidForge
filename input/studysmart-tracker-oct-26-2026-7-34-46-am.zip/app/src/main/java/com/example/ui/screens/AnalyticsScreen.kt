package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MistakeCategory
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionMistake
import com.example.data.model.ReviewStatus
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask
import com.example.ui.components.LogNeetMockDialog
import com.example.ui.theme.CarelessColor
import com.example.ui.theme.CarelessContainer
import com.example.ui.theme.ConceptualColor
import com.example.ui.theme.ConceptualContainer
import com.example.ui.theme.CremeBackground
import com.example.ui.theme.CremeOutline
import com.example.ui.theme.CremeOutlineVariant
import com.example.ui.theme.CremeSurface
import com.example.ui.theme.CremeSurfaceVariant
import com.example.ui.theme.EspressoText
import com.example.ui.theme.PrimaryEspresso
import com.example.ui.theme.StoneSubtext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AnalyticsScreen(
    mistakes: List<QuestionMistake>,
    tasks: List<StudyTask>,
    studyLogs: List<StudyLog>,
    neetMockTests: List<NeetMockTest>,
    totalStudyMinutes: Int,
    onLogNeetMock: (
        title: String,
        physicsScore: Int,
        chemistryScore: Int,
        biologyScore: Int,
        carelessMistakesCount: Int,
        conceptualMistakesCount: Int,
        notes: String
    ) -> Unit,
    onDeleteNeetMock: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showLogMockDialog by remember { mutableStateOf(false) }

    val totalMistakes = mistakes.size.coerceAtLeast(1)
    val conceptualMistakes = mistakes.count { it.mistakeCategory == MistakeCategory.CONCEPTUAL.name }
    val carelessMistakes = mistakes.count { it.mistakeCategory == MistakeCategory.CARELESS.name }
    val misreadMistakes = mistakes.count { it.mistakeCategory == MistakeCategory.MISREAD_QUESTION.name }

    val conceptualPercent = (conceptualMistakes * 100) / totalMistakes
    val carelessPercent = (carelessMistakes * 100) / totalMistakes

    // NEET Mock calculations
    val latestMock = neetMockTests.lastOrNull()
    val peakScore = neetMockTests.maxOfOrNull { it.totalScore } ?: 0
    val averageScore = if (neetMockTests.isNotEmpty()) neetMockTests.map { it.totalScore }.average().toInt() else 0

    val avgPhysics = if (neetMockTests.isNotEmpty()) neetMockTests.map { it.physicsScore }.average().toInt() else 0
    val avgChemistry = if (neetMockTests.isNotEmpty()) neetMockTests.map { it.chemistryScore }.average().toInt() else 0
    val avgBiology = if (neetMockTests.isNotEmpty()) neetMockTests.map { it.biologyScore }.average().toInt() else 0

    val totalCarelessSlipsInMocks = neetMockTests.sumOf { it.carelessMistakesCount }
    val potentialScoreBoost = totalCarelessSlipsInMocks * 5 // Each NEET mistake = 4 marks missed + 1 negative mark

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CremeBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Screen Header with "+ Log NEET Mock"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEET Mock Analytics",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = EspressoText
                    )
                    Text(
                        text = "Track your progress out of 720 towards target GMC",
                        fontSize = 12.sp,
                        color = StoneSubtext
                    )
                }

                Button(
                    onClick = { showLogMockDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryEspresso,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("button_open_log_mock")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Mock", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Top Stat Cards (Crème Minimalist)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Latest Score Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Latest Score", fontSize = 11.sp, color = StoneSubtext)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (latestMock != null) "${latestMock.totalScore}" else "--",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = EspressoText
                            )
                            Text(" / 720", fontSize = 11.sp, color = StoneSubtext)
                        }
                        Text(
                            text = if (latestMock != null) "P:${latestMock.physicsScore} C:${latestMock.chemistryScore} B:${latestMock.biologyScore}" else "No tests yet",
                            fontSize = 10.sp,
                            color = StoneSubtext,
                            maxLines = 1
                        )
                    }
                }

                // Peak Score Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Peak Score", fontSize = 11.sp, color = StoneSubtext)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (peakScore > 0) "$peakScore" else "--",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (peakScore >= 600) Color(0xFF16A34A) else EspressoText
                            )
                            Text(" / 720", fontSize = 11.sp, color = StoneSubtext)
                        }
                        Text(
                            text = if (peakScore >= 650) "🎯 Target Met!" else "${(650 - peakScore).coerceAtLeast(0)} pts to 650+",
                            fontSize = 10.sp,
                            color = if (peakScore >= 650) Color(0xFF16A34A) else CarelessColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Average Score Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Average", fontSize = 11.sp, color = StoneSubtext)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (averageScore > 0) "$averageScore" else "--",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = EspressoText
                            )
                            Text(" / 720", fontSize = 11.sp, color = StoneSubtext)
                        }
                        Text(
                            text = "${neetMockTests.size} tests logged",
                            fontSize = 10.sp,
                            color = StoneSubtext
                        )
                    }
                }
            }

            // PRIMARY SECTION: NEET MOCK TEST PROGRESS GRAPH
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("neet_progress_graph_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CremeSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    tint = PrimaryEspresso,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "NEET Score Progression",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = EspressoText
                                )
                            }
                            Text(
                                text = "Test-by-test progress against the 650+ GMC target",
                                fontSize = 11.sp,
                                color = StoneSubtext
                            )
                        }

                        // Target Legend
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CarelessContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(CarelessColor)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Target 650", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CarelessColor)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (neetMockTests.isEmpty()) {
                        // Empty graph placeholder
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CremeSurfaceVariant.copy(alpha = 0.5f))
                                .border(1.dp, CremeOutlineVariant, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = null,
                                    tint = StoneSubtext,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No NEET Mock Tests Recorded Yet",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EspressoText
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Log your test scores (Physics, Chemistry, Biology) to view your progression curve and target lines.",
                                    fontSize = 11.sp,
                                    color = StoneSubtext,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { showLogMockDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryEspresso)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Log Your First Mock", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        // NATIVE CANVAS NEET PROGRESS GRAPH
                        NeetScoreCanvasGraph(tests = neetMockTests)
                    }
                }
            }

            // Subject-Wise Average Performance Bar (/180, /180, /360)
            if (neetMockTests.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Subject Average Mastery",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EspressoText
                        )
                        Text(
                            text = "Your average yield across Physics (/180), Chemistry (/180), and Biology (/360)",
                            fontSize = 11.sp,
                            color = StoneSubtext
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Physics
                        SubjectScoreRow(
                            name = "Physics",
                            score = avgPhysics,
                            maxMarks = 180,
                            barColor = Color(0xFF1E3A8A)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Chemistry
                        SubjectScoreRow(
                            name = "Chemistry",
                            score = avgChemistry,
                            maxMarks = 180,
                            barColor = Color(0xFF0F766E)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Biology
                        SubjectScoreRow(
                            name = "Biology",
                            score = avgBiology,
                            maxMarks = 360,
                            barColor = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            // NEET Careless Negative Marking Diagnostic
            if (totalCarelessSlipsInMocks > 0 || carelessMistakes > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CarelessContainer.copy(alpha = 0.5f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CarelessColor.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = CarelessColor, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Careless Negative Marking Audit",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = CarelessColor
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "In NEET, each incorrect response costs 5 marks (+4 marks unobtained plus -1 negative mark penalty).",
                            fontSize = 12.sp,
                            color = EspressoText
                        )

                        if (totalCarelessSlipsInMocks > 0 && latestMock != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            val adjustedScore = (latestMock.totalScore + (latestMock.carelessMistakesCount * 5)).coerceAtMost(720)
                            Text(
                                text = "Latest test: ${latestMock.carelessMistakesCount} careless slips cost you ${latestMock.carelessMistakesCount * 5} marks. Your potential score without calculation slips is $adjustedScore / 720!",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CarelessColor
                            )
                        }
                    }
                }
            }

            // Logged Mock Tests List
            if (neetMockTests.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Mock Test History",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = EspressoText
                            )
                            Text(
                                text = "${neetMockTests.size} tests",
                                fontSize = 11.sp,
                                color = StoneSubtext
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        neetMockTests.reversed().forEach { test ->
                            MockTestHistoryItem(
                                test = test,
                                onDelete = { onDeleteNeetMock(test.id) }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }

            // Mistake Notebook Breakdown (Conceptual vs Careless in Notebook)
            if (mistakes.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Question Mistake Notebook Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = EspressoText
                        )
                        Text(
                            text = "${mistakes.size} questions logged across Physics, Chemistry & Biology",
                            fontSize = 11.sp,
                            color = StoneSubtext
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Multi-segment Proportion Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CremeSurfaceVariant)
                        ) {
                            if (conceptualMistakes > 0) {
                                Box(
                                    modifier = Modifier
                                        .weight(conceptualMistakes.toFloat())
                                        .background(ConceptualColor)
                                )
                            }
                            if (carelessMistakes > 0) {
                                Box(
                                    modifier = Modifier
                                        .weight(carelessMistakes.toFloat())
                                        .background(CarelessColor)
                                )
                            }
                            if (misreadMistakes > 0) {
                                Box(
                                    modifier = Modifier
                                        .weight(misreadMistakes.toFloat())
                                        .background(Color(0xFF6941C6))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Conceptual Pill
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ConceptualContainer)
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = ConceptualColor, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Conceptual", fontSize = 10.sp, color = StoneSubtext)
                                    Text("$conceptualMistakes ($conceptualPercent%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ConceptualColor)
                                }
                            }

                            // Careless Pill
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CarelessContainer)
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Calculate, contentDescription = null, tint = CarelessColor, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Careless", fontSize = 10.sp, color = StoneSubtext)
                                    Text("$carelessMistakes ($carelessPercent%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CarelessColor)
                                }
                            }
                        }
                    }
                }
            }

            // NEET Specific Strategy Recommendations
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CremeSurfaceVariant.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryEspresso, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "NEET Preparation Insights",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = EspressoText
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Biology High Yield: Aim for 340+ in Biology (NCERT line-by-line) to anchor your total score above 600.",
                        fontSize = 11.sp,
                        color = StoneSubtext
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Careless Sign Audit: Always spend the last 5 minutes checking signs, units, and powers of 10 in Physics calculations.",
                        fontSize = 11.sp,
                        color = StoneSubtext
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Spaced Repetition: Review your Mistake Notebook questions 1 day and 3 days after each mock test.",
                        fontSize = 11.sp,
                        color = StoneSubtext
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    if (showLogMockDialog) {
        LogNeetMockDialog(
            onDismiss = { showLogMockDialog = false },
            onSaveTest = { title, physicsScore, chemistryScore, biologyScore, carelessMistakesCount, conceptualMistakesCount, notes ->
                onLogNeetMock(
                    title,
                    physicsScore,
                    chemistryScore,
                    biologyScore,
                    carelessMistakesCount,
                    conceptualMistakesCount,
                    notes
                )
            }
        )
    }
}

@Composable
private fun NeetScoreCanvasGraph(tests: List<NeetMockTest>) {
    val displayTests = remember(tests) { tests.takeLast(10) }
    val maxScore = 720f
    val targetScore = 650f

    val linePathColor = PrimaryEspresso
    val targetColor = CarelessColor
    val guideColor = CremeOutline

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CremeSurfaceVariant.copy(alpha = 0.35f))
            .border(1.dp, CremeOutlineVariant, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val bottomPadding = 30f
            val topPadding = 25f
            val graphHeight = height - bottomPadding - topPadding

            fun scoreToY(score: Float): Float {
                val clamped = score.coerceIn(0f, maxScore)
                return topPadding + (graphHeight * (1f - (clamped / maxScore)))
            }

            // Draw horizontal guide lines: 720, 650 (Target), 500, 360
            val guideScores = listOf(720f, 500f, 360f)
            val strokeDotted = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)

            guideScores.forEach { s ->
                val y = scoreToY(s)
                drawLine(
                    color = guideColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f,
                    pathEffect = strokeDotted
                )
            }

            // Target 650 line (dashed warm terracotta)
            val targetY = scoreToY(targetScore)
            drawLine(
                color = targetColor,
                start = Offset(0f, targetY),
                end = Offset(width, targetY),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
            )

            // Draw points & line
            val count = displayTests.size
            if (count == 1) {
                val test = displayTests[0]
                val ptX = width / 2f
                val ptY = scoreToY(test.totalScore.toFloat())

                // Draw point
                drawCircle(color = linePathColor, radius = 6f, center = Offset(ptX, ptY))
                drawCircle(color = Color.White, radius = 3f, center = Offset(ptX, ptY))
            } else if (count > 1) {
                val stepX = width / (count - 1).toFloat()
                val path = Path()
                val fillPath = Path()

                val points = displayTests.mapIndexed { i, test ->
                    Offset(i * stepX, scoreToY(test.totalScore.toFloat()))
                }

                path.moveTo(points[0].x, points[0].y)
                fillPath.moveTo(points[0].x, height - bottomPadding)
                fillPath.lineTo(points[0].x, points[0].y)

                for (i in 1 until points.size) {
                    val prev = points[i - 1]
                    val curr = points[i]
                    val cX = (prev.x + curr.x) / 2f
                    path.cubicTo(cX, prev.y, cX, curr.y, curr.x, curr.y)
                    fillPath.cubicTo(cX, prev.y, cX, curr.y, curr.x, curr.y)
                }

                fillPath.lineTo(points.last().x, height - bottomPadding)
                fillPath.close()

                // Draw soft gradient fill
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(linePathColor.copy(alpha = 0.18f), Color.Transparent),
                        startY = topPadding,
                        endY = height - bottomPadding
                    )
                )

                // Draw line stroke
                drawPath(
                    path = path,
                    color = linePathColor,
                    style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                )

                // Draw circular nodes
                points.forEach { pt ->
                    drawCircle(color = linePathColor, radius = 5.5f, center = pt)
                    drawCircle(color = Color.White, radius = 2.5f, center = pt)
                }
            }
        }

        // Top benchmark label
        Text(
            text = "Target 650 (GMC Benchmark)",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = CarelessColor,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 4.dp, top = 2.dp)
        )

        // Bottom test names row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            displayTests.forEachIndexed { idx, test ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${test.totalScore}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EspressoText
                    )
                    Text(
                        text = "M${idx + 1}",
                        fontSize = 9.sp,
                        color = StoneSubtext
                    )
                }
            }
        }
    }
}

@Composable
private fun SubjectScoreRow(
    name: String,
    score: Int,
    maxMarks: Int,
    barColor: Color
) {
    val percentage = ((score.toFloat() / maxMarks) * 100).toInt().coerceIn(0, 100)
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = EspressoText)
            Text("$score / $maxMarks ($percentage%)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = barColor)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score.toFloat() / maxMarks },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = barColor,
            trackColor = CremeSurfaceVariant
        )
    }
}

@Composable
private fun MockTestHistoryItem(
    test: NeetMockTest,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val formattedDate = remember(test.dateMillis) { dateFormat.format(Date(test.dateMillis)) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CremeSurfaceVariant.copy(alpha = 0.4f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(test.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EspressoText)
                Text(formattedDate, fontSize = 10.sp, color = StoneSubtext)

                Spacer(modifier = Modifier.height(4.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phy: ${test.physicsScore}/180", fontSize = 10.sp, color = Color(0xFF1E3A8A), fontWeight = FontWeight.SemiBold)
                    Text("Chem: ${test.chemistryScore}/180", fontSize = 10.sp, color = Color(0xFF0F766E), fontWeight = FontWeight.SemiBold)
                    Text("Bio: ${test.biologyScore}/360", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                }

                if (test.carelessMistakesCount > 0) {
                    Text(
                        text = "• ${test.carelessMistakesCount} careless slips (-${test.carelessMistakesCount * 5} marks lost)",
                        fontSize = 10.sp,
                        color = CarelessColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${test.totalScore} / 720",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (test.totalScore >= 600) Color(0xFF16A34A) else EspressoText
                )

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Test",
                        tint = StoneSubtext,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
