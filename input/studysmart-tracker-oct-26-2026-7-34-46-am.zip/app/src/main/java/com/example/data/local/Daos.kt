package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Chapter
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionMistake
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE subject = :subject ORDER BY priority DESC, name ASC")
    fun getChaptersForSubject(subject: String): Flow<List<Chapter>>

    @Query("SELECT * FROM chapters ORDER BY priority DESC, name ASC")
    fun getAllChapters(): Flow<List<Chapter>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: Chapter): Long

    @Update
    suspend fun updateChapter(chapter: Chapter)

    @Query("UPDATE chapters SET priority = :priority WHERE id = :id")
    suspend fun updateChapterPriority(id: Long, priority: Int)

    @Query("DELETE FROM chapters WHERE id = :id")
    suspend fun deleteChapterById(id: Long)
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM question_mistakes ORDER BY createdAt DESC")
    fun getAllMistakes(): Flow<List<QuestionMistake>>

    @Query("SELECT * FROM question_mistakes WHERE id = :id LIMIT 1")
    suspend fun getMistakeById(id: Long): QuestionMistake?

    @Query("SELECT * FROM question_mistakes WHERE subject = :subject ORDER BY createdAt DESC")
    fun getMistakesBySubject(subject: String): Flow<List<QuestionMistake>>

    @Query("SELECT * FROM question_mistakes WHERE subject = :subject AND topic = :chapterName ORDER BY createdAt DESC")
    fun getMistakesForChapter(subject: String, chapterName: String): Flow<List<QuestionMistake>>

    @Query("SELECT * FROM question_mistakes WHERE mistakeCategory = :category ORDER BY createdAt DESC")
    fun getMistakesByCategory(category: String): Flow<List<QuestionMistake>>

    @Query("SELECT * FROM question_mistakes WHERE status = :status ORDER BY createdAt DESC")
    fun getMistakesByStatus(status: String): Flow<List<QuestionMistake>>

    @Query("SELECT * FROM question_mistakes WHERE nextReviewDate <= :cutoffTime AND status != 'MASTERED' ORDER BY nextReviewDate ASC")
    fun getQuestionsDueForReview(cutoffTime: Long): Flow<List<QuestionMistake>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMistake(mistake: QuestionMistake): Long

    @Update
    suspend fun updateMistake(mistake: QuestionMistake)

    @Delete
    suspend fun deleteMistake(mistake: QuestionMistake)

    @Query("DELETE FROM question_mistakes WHERE id = :id")
    suspend fun deleteMistakeById(id: Long)

    @Query("SELECT COUNT(*) FROM question_mistakes")
    fun getTotalMistakesCount(): Flow<Int>
}

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY dateMillis ASC, startTime ASC")
    fun getAllTasks(): Flow<List<StudyTask>>

    @Query("SELECT * FROM study_tasks WHERE dateMillis >= :startOfDay AND dateMillis <= :endOfDay ORDER BY startTime ASC")
    fun getTasksForDate(startOfDay: Long, endOfDay: Long): Flow<List<StudyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTask): Long

    @Update
    suspend fun updateTask(task: StudyTask)

    @Delete
    suspend fun deleteTask(task: StudyTask)

    @Query("DELETE FROM study_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)
}

@Dao
interface StudyLogDao {
    @Query("SELECT * FROM study_logs ORDER BY dateMillis DESC")
    fun getAllLogs(): Flow<List<StudyLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: StudyLog): Long

    @Query("SELECT SUM(durationMinutes) FROM study_logs")
    fun getTotalStudyMinutes(): Flow<Int?>
}

@Dao
interface NeetMockTestDao {
    @Query("SELECT * FROM neet_mock_tests ORDER BY dateMillis ASC")
    fun getAllTestsAsc(): Flow<List<NeetMockTest>>

    @Query("SELECT * FROM neet_mock_tests ORDER BY dateMillis DESC")
    fun getAllTestsDesc(): Flow<List<NeetMockTest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTest(test: NeetMockTest): Long

    @Query("DELETE FROM neet_mock_tests WHERE id = :id")
    suspend fun deleteTestById(id: Long)
}
