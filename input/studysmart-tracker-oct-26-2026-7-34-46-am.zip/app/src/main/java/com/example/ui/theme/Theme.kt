package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Minimalist Warm Crème Color Scheme
private val CremeColorScheme = lightColorScheme(
    primary = PrimaryEspresso,
    onPrimary = OnPrimaryEspresso,
    primaryContainer = PrimaryContainerCreme,
    onPrimaryContainer = OnPrimaryContainerCreme,
    secondary = SecondaryStone,
    onSecondary = OnSecondaryStone,
    secondaryContainer = SecondaryContainerStone,
    onSecondaryContainer = OnSecondaryContainerStone,
    tertiary = TertiaryWarmLatte,
    onTertiary = OnTertiaryWarmLatte,
    tertiaryContainer = TertiaryContainerLatte,
    onTertiaryContainer = OnTertiaryContainerLatte,
    background = CremeBackground,
    onBackground = EspressoText,
    surface = CremeSurface,
    onSurface = EspressoText,
    surfaceVariant = CremeSurfaceVariant,
    onSurfaceVariant = StoneSubtext,
    outline = CremeOutline,
    outlineVariant = CremeOutlineVariant
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Enforce minimalist warm creme aesthetic without dark vibe
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CremeColorScheme,
        typography = Typography,
        content = content
    )
}
