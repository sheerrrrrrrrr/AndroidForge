package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ImageStorageManager
import com.example.data.model.Chapter
import com.example.data.model.MistakeCategory
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionDifficulty
import com.example.data.model.QuestionMistake
import com.example.data.model.ReviewStatus
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: StudyRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = StudyRepository(
            database.questionDao(),
            database.studyTaskDao(),
            database.studyLogDao(),
            database.chapterDao(),
            database.neetMockTestDao()
        )
    }

    val allMistakes: StateFlow<List<QuestionMistake>> = repository.allMistakes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasks: StateFlow<List<StudyTask>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<StudyLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalStudyMinutes: StateFlow<Int?> = repository.totalStudyMinutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val allChapters: StateFlow<List<Chapter>> = repository.allChapters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val neetMockTests: StateFlow<List<NeetMockTest>> = repository.allNeetTestsAsc
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Hierarchical Navigation State for Mistakes Tab:
    // Level 0: selectedSubject == null (Subjects Screen: Physics, Chemistry, Biology)
    // Level 1: selectedSubject != null && selectedChapter == null (Chapters Screen)
    // Level 2: selectedSubject != null && selectedChapter != null (Questions in this Chapter)
    private val _selectedSubject = MutableStateFlow<String?>(null)
    val selectedSubject: StateFlow<String?> = _selectedSubject.asStateFlow()

    private val _selectedChapter = MutableStateFlow<Chapter?>(null)
    val selectedChapter: StateFlow<Chapter?> = _selectedChapter.asStateFlow()

    fun selectSubject(subject: String?) {
        _selectedSubject.value = subject
        _selectedChapter.value = null // reset chapter selection
    }

    fun selectChapter(chapter: Chapter?) {
        _selectedChapter.value = chapter
    }

    fun addChapter(subject: String, chapterName: String, priority: Int = 50) {
        val trimmed = chapterName.trim()
        if (trimmed.isBlank()) return
        val clampedPriority = priority.coerceIn(1, 100)
        viewModelScope.launch {
            repository.insertChapter(
                Chapter(
                    subject = subject,
                    name = trimmed,
                    priority = clampedPriority
                )
            )
        }
    }

    fun updateChapterPriority(chapter: Chapter, newPriority: Int) {
        val clamped = newPriority.coerceIn(1, 100)
        viewModelScope.launch {
            repository.updateChapterPriority(chapter.id, clamped)
            if (_selectedChapter.value?.id == chapter.id) {
                _selectedChapter.value = _selectedChapter.value?.copy(priority = clamped)
            }
        }
    }

    fun deleteChapter(chapter: Chapter) {
        viewModelScope.launch {
            repository.deleteChapter(chapter.id)
            if (_selectedChapter.value?.id == chapter.id) {
                _selectedChapter.value = null
            }
        }
    }

    // Calendar selected day (defaults to start of today)
    private val _selectedDateMillis = MutableStateFlow(getStartOfDay(System.currentTimeMillis()))
    val selectedDateMillis: StateFlow<Long> = _selectedDateMillis.asStateFlow()

    fun setSelectedDate(dateMillis: Long) {
        _selectedDateMillis.value = getStartOfDay(dateMillis)
    }

    // Filter and search states
    val searchQuery = MutableStateFlow("")
    val selectedCategoryFilter = MutableStateFlow<String?>(null) // null = all
    val selectedStatusFilter = MutableStateFlow<String?>(null) // null = all

    // Questions due for review today or overdue
    val reviewDueQuestions: StateFlow<List<QuestionMistake>> = repository.getQuestionsDueForReview(
        getEndOfDay(System.currentTimeMillis())
    ).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tasks for currently selected calendar date
    val tasksForSelectedDate: StateFlow<List<StudyTask>> = combine(
        allTasks,
        selectedDateMillis
    ) { tasks, date ->
        val start = getStartOfDay(date)
        val end = getEndOfDay(date)
        tasks.filter { it.dateMillis in start..end }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Operations
    fun addQuestion(
        title: String,
        subject: String,
        topic: String,
        mistakeCategory: MistakeCategory,
        whatWentWrong: String,
        correctApproach: String,
        correctAnswer: String,
        difficulty: QuestionDifficulty,
        imageUri: Uri?
    ) {
        viewModelScope.launch {
            var savedPath: String? = null
            if (imageUri != null) {
                savedPath = ImageStorageManager.saveImageToInternalStorage(getApplication(), imageUri)
            }
            val trimmedTopic = topic.trim()
            val mistake = QuestionMistake(
                title = title.trim(),
                subject = subject.trim(),
                topic = trimmedTopic,
                imagePath = savedPath,
                mistakeCategory = mistakeCategory.name,
                whatWentWrong = whatWentWrong.trim(),
                correctApproach = correctApproach.trim(),
                correctAnswer = correctAnswer.trim(),
                difficulty = difficulty.name,
                status = ReviewStatus.NEEDS_REVIEW.name,
                nextReviewDate = System.currentTimeMillis() + (24L * 60 * 60 * 1000)
            )
            repository.insertMistake(mistake)

            // Auto-store chapter if not already present
            if (trimmedTopic.isNotBlank()) {
                val exists = allChapters.value.any {
                    it.subject.equals(subject.trim(), ignoreCase = true) &&
                            it.name.equals(trimmedTopic, ignoreCase = true)
                }
                if (!exists) {
                    repository.insertChapter(
                        Chapter(subject = subject.trim(), name = trimmedTopic)
                    )
                }
            }
        }
    }

    fun updateQuestion(
        id: Long,
        title: String,
        subject: String,
        topic: String,
        mistakeCategory: MistakeCategory,
        whatWentWrong: String,
        correctApproach: String,
        correctAnswer: String,
        difficulty: QuestionDifficulty,
        newImageUri: Uri?,
        existingImagePath: String?
    ) {
        viewModelScope.launch {
            var path = existingImagePath
            if (newImageUri != null) {
                val newSaved = ImageStorageManager.saveImageToInternalStorage(getApplication(), newImageUri)
                if (newSaved != null) {
                    ImageStorageManager.deleteImageFile(existingImagePath)
                    path = newSaved
                }
            }

            val current = allMistakes.value.firstOrNull { it.id == id }
            if (current != null) {
                val updated = current.copy(
                    title = title.trim(),
                    subject = subject.trim(),
                    topic = topic.trim(),
                    imagePath = path,
                    mistakeCategory = mistakeCategory.name,
                    whatWentWrong = whatWentWrong.trim(),
                    correctApproach = correctApproach.trim(),
                    correctAnswer = correctAnswer.trim(),
                    difficulty = difficulty.name
                )
                repository.updateMistake(updated)
            }
        }
    }

    fun deleteQuestion(mistake: QuestionMistake) {
        viewModelScope.launch {
            ImageStorageManager.deleteImageFile(mistake.imagePath)
            repository.deleteMistake(mistake.id)
        }
    }

    fun recordReview(mistake: QuestionMistake, gotItRight: Boolean) {
        viewModelScope.launch {
            repository.recordReviewResult(mistake, gotItRight)
        }
    }

    fun addStudyTask(
        title: String,
        subject: String,
        dateMillis: Long,
        startTime: String,
        durationMinutes: Int,
        sessionType: String,
        notes: String
    ) {
        viewModelScope.launch {
            val task = StudyTask(
                title = title.trim(),
                subject = subject.trim(),
                dateMillis = getStartOfDay(dateMillis),
                startTime = startTime,
                durationMinutes = durationMinutes,
                sessionType = sessionType,
                isCompleted = false,
                notes = notes.trim()
            )
            repository.insertTask(task)
        }
    }

    fun toggleTaskCompleted(task: StudyTask) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(id: Long) {
        viewModelScope.launch {
            repository.deleteTask(id)
        }
    }

    fun logCompletedStudySession(durationMinutes: Int, subject: String, notes: String) {
        viewModelScope.launch {
            val log = StudyLog(
                dateMillis = System.currentTimeMillis(),
                durationMinutes = durationMinutes,
                subject = subject,
                sessionNote = notes
            )
            repository.insertLog(log)
        }
    }

    fun logNeetMockTest(
        title: String,
        physicsScore: Int,
        chemistryScore: Int,
        biologyScore: Int,
        carelessMistakesCount: Int = 0,
        conceptualMistakesCount: Int = 0,
        notes: String = "",
        dateMillis: Long = System.currentTimeMillis()
    ) {
        val total = (physicsScore + chemistryScore + biologyScore).coerceIn(0, 720)
        viewModelScope.launch {
            repository.insertNeetTest(
                NeetMockTest(
                    title = title.trim().ifBlank { "NEET Full Mock" },
                    physicsScore = physicsScore,
                    chemistryScore = chemistryScore,
                    biologyScore = biologyScore,
                    totalScore = total,
                    maxMarks = 720,
                    carelessMistakesCount = carelessMistakesCount,
                    conceptualMistakesCount = conceptualMistakesCount,
                    dateMillis = dateMillis,
                    notes = notes.trim()
                )
            )
        }
    }

    fun deleteNeetMockTest(id: Long) {
        viewModelScope.launch {
            repository.deleteNeetTest(id)
        }
    }

    companion object {
        fun getStartOfDay(timeMillis: Long): Long {
            val cal = Calendar.getInstance().apply {
                timeInMillis = timeMillis
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        fun getEndOfDay(timeMillis: Long): Long {
            val cal = Calendar.getInstance().apply {
                timeInMillis = timeMillis
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            }
            return cal.timeInMillis
        }
    }
}
