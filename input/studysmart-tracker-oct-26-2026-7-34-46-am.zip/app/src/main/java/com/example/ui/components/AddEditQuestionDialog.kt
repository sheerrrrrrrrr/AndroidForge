package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.MistakeCategory
import com.example.data.model.QuestionDifficulty
import com.example.data.model.QuestionMistake
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditQuestionDialog(
    questionToEdit: QuestionMistake? = null,
    presetSubject: String? = null,
    presetTopic: String? = null,
    availableChapters: List<String> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        subject: String,
        topic: String,
        category: MistakeCategory,
        whatWentWrong: String,
        correctApproach: String,
        correctAnswer: String,
        difficulty: QuestionDifficulty,
        imageUri: Uri?
    ) -> Unit
) {
    val isEditMode = questionToEdit != null

    var title by remember { mutableStateOf(questionToEdit?.title ?: "") }
    val subjects = remember { listOf("Physics", "Chemistry", "Biology") }
    var subject by remember {
        mutableStateOf(
            questionToEdit?.subject ?: presetSubject ?: "Physics"
        )
    }
    var subjectExpanded by remember { mutableStateOf(false) }

    var topic by remember {
        mutableStateOf(questionToEdit?.topic ?: presetTopic ?: "")
    }

    var selectedCategory by remember {
        mutableStateOf(
            if (questionToEdit != null) MistakeCategory.fromString(questionToEdit.mistakeCategory)
            else MistakeCategory.CONCEPTUAL
        )
    }

    var whatWentWrong by remember { mutableStateOf(questionToEdit?.whatWentWrong ?: "") }
    var correctApproach by remember { mutableStateOf(questionToEdit?.correctApproach ?: "") }
    var correctAnswer by remember { mutableStateOf(questionToEdit?.correctAnswer ?: "") }

    var difficulty by remember {
        mutableStateOf(
            if (questionToEdit != null) QuestionDifficulty.valueOf(questionToEdit.difficulty)
            else QuestionDifficulty.MEDIUM
        )
    }

    // Photo state
    var pickedImageUri by remember { mutableStateOf<Uri?>(null) }
    var currentPhotoPath by remember { mutableStateOf(questionToEdit?.imagePath) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            pickedImageUri = uri
            currentPhotoPath = null
        }
    }

    var showError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEditMode) "Edit Missed Question" else "Log Missed Question",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Section: Photo of the Question
                Text(
                    text = "Question Photo",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))

                val hasImage = pickedImageUri != null || !currentPhotoPath.isNullOrBlank()

                if (hasImage) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    ) {
                        val imageModel = pickedImageUri ?: File(currentPhotoPath ?: "")
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(imageModel)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Question Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                        ) {
                            IconButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Change Photo",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(
                                onClick = {
                                    pickedImageUri = null
                                    currentPhotoPath = null
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove Photo",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .testTag("button_pick_photo"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Attach Photo of Question / Problem", fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title / Question Prompt
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Question Title / Summary *") },
                    placeholder = { Text("e.g. Kinematics projectile problem or Test Q4") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_question_title"),
                    isError = showError && title.isBlank(),
                    supportingText = {
                        if (showError && title.isBlank()) {
                            Text("Question title is required", color = MaterialTheme.colorScheme.error)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Subject & Chapter Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = subjectExpanded,
                        onExpandedChange = { subjectExpanded = !subjectExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Subject") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = subjectExpanded,
                            onDismissRequest = { subjectExpanded = false }
                        ) {
                            subjects.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item) },
                                    onClick = {
                                        subject = item
                                        subjectExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Chapter *") },
                        placeholder = { Text("e.g. Thermodynamics") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_question_topic"),
                        isError = showError && topic.isBlank(),
                        supportingText = {
                            if (showError && topic.isBlank()) {
                                Text("Chapter is required", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    )
                }

                // Quick chips for available chapters if present
                if (availableChapters.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Select from stored chapters:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        availableChapters.forEach { chap ->
                            FilterChip(
                                selected = topic.equals(chap, ignoreCase = true),
                                onClick = { topic = chap },
                                label = { Text(chap, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Mistake Category Selector (Core requirement: Conceptual vs Careless)
                Text(
                    text = "Type of Mistake *",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Reflect honestly on the primary source of the error:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))

                MistakeCategory.entries.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    val style = getCategoryStyle(cat.name)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedCategory = cat }
                            .testTag("category_select_${cat.name.lowercase()}"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) style.containerColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, style.color) else null
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = style.icon,
                                contentDescription = null,
                                tint = if (isSelected) style.color else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cat.displayName,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) style.color else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = cat.description,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // What I Did Wrong (Reflection Area)
                OutlinedTextField(
                    value = whatWentWrong,
                    onValueChange = { whatWentWrong = it },
                    label = { Text("What I Did Wrong (Self-Reflection) *") },
                    placeholder = {
                        Text(
                            when (selectedCategory) {
                                MistakeCategory.CONCEPTUAL -> "e.g. Conceptual misunderstanding: Assumed force was constant..."
                                MistakeCategory.CARELESS -> "e.g. Careless error: Dropped a minus sign when calculating velocity..."
                                MistakeCategory.MISREAD_QUESTION -> "e.g. Misread the question: Didn't notice the word 'NOT' in option C..."
                                else -> "e.g. What specific step tripped you up?"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("input_what_went_wrong"),
                    isError = showError && whatWentWrong.isBlank(),
                    supportingText = {
                        if (showError && whatWentWrong.isBlank()) {
                            Text("Please reflect on what went wrong", color = MaterialTheme.colorScheme.error)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Correct Approach & Key Takeaway
                OutlinedTextField(
                    value = correctApproach,
                    onValueChange = { correctApproach = it },
                    label = { Text("Correct Approach & Key Rule to Remember") },
                    placeholder = { Text("e.g. The correct theorem to apply is conservation of momentum...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("input_correct_approach")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Correct Answer
                OutlinedTextField(
                    value = correctAnswer,
                    onValueChange = { correctAnswer = it },
                    label = { Text("Correct Final Answer (optional)") },
                    placeholder = { Text("e.g. 9.8 m/s² or Option B") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Difficulty selector
                Text(
                    text = "Difficulty Level",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuestionDifficulty.entries.forEach { diff ->
                        val isSelected = difficulty == diff
                        FilterChip(
                            selected = isSelected,
                            onClick = { difficulty = diff },
                            label = { Text(diff.name.lowercase().replaceFirstChar { it.uppercase() }) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || whatWentWrong.isBlank() || topic.isBlank()) {
                        showError = true
                        return@Button
                    }
                    onSave(
                        title,
                        subject,
                        topic,
                        selectedCategory,
                        whatWentWrong,
                        correctApproach,
                        correctAnswer,
                        difficulty,
                        pickedImageUri
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("button_save_question")
            ) {
                Text(if (isEditMode) "Save Changes" else "Log Question")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
