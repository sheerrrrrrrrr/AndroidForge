package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.data.model.Chapter
import com.example.data.model.QuestionMistake
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExportManager {

    suspend fun generateChapterPdf(
        context: Context,
        subject: String,
        chapter: Chapter,
        questions: List<QuestionMistake>
    ): File? = withContext(Dispatchers.IO) {
        try {
            val pdfDir = File(context.filesDir, "pdfs")
            if (!pdfDir.exists()) {
                pdfDir.mkdirs()
            }

            val sanitizedChapter = chapter.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val sanitizedSubject = subject.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val fileName = "${sanitizedSubject}_${sanitizedChapter}_Questions.pdf"
            val file = File(pdfDir, fileName)

            val document = PdfDocument()

            // Standard A4: 595 x 842 points
            val pageWidth = 595
            val pageHeight = 842
            val margin = 40f
            val contentWidth = (pageWidth - (margin * 2)).toInt()

            var pageNumber = 1
            var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            var page = document.startPage(pageInfo)
            var canvas = page.canvas

            // Paints
            val textPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.rgb(30, 41, 59)
                textSize = 11f
            }

            val boldPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.rgb(15, 23, 42)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
            }

            val headerPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.rgb(30, 64, 175) // Primary Blue
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
            }

            val metaPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.rgb(100, 116, 139)
                textSize = 10f
            }

            val linePaint = Paint().apply {
                color = Color.rgb(226, 232, 240)
                strokeWidth = 1f
            }

            val cardBgPaint = Paint().apply {
                color = Color.rgb(248, 250, 252)
                style = Paint.Style.FILL
            }

            val errorBadgePaint = Paint().apply {
                color = Color.rgb(254, 226, 226) // light red
                style = Paint.Style.FILL
            }

            val carelessBadgePaint = Paint().apply {
                color = Color.rgb(254, 243, 199) // light amber
                style = Paint.Style.FILL
            }

            var currentY = margin

            fun drawPageFooter(c: Canvas, pNum: Int) {
                val footerText = "StudyPulse Mistake Notebook  •  Page $pNum"
                val fWidth = metaPaint.measureText(footerText)
                c.drawText(footerText, (pageWidth - fWidth) / 2f, pageHeight - 20f, metaPaint)
            }

            // Draw Header on first page
            canvas.drawText("${subject.uppercase()} — MISTAKE NOTEBOOK", margin, currentY + 18f, headerPaint)
            currentY += 28f

            boldPaint.textSize = 14f
            canvas.drawText("Chapter: ${chapter.name}", margin, currentY + 14f, boldPaint)
            currentY += 22f
            boldPaint.textSize = 12f

            val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
            val dateStr = "Total Questions: ${questions.size}  •  Exported on ${dateFormat.format(Date())}"
            canvas.drawText(dateStr, margin, currentY + 10f, metaPaint)
            currentY += 20f

            canvas.drawLine(margin, currentY, pageWidth - margin, currentY, linePaint)
            currentY += 18f

            if (questions.isEmpty()) {
                val emptyLayout = StaticLayout.Builder.obtain(
                    "No questions stored in this chapter yet.",
                    0,
                    "No questions stored in this chapter yet.".length,
                    textPaint,
                    contentWidth
                ).build()
                emptyLayout.draw(canvas)
            } else {
                for ((index, mistake) in questions.withIndex()) {
                    val serialNumber = index + 1
                    val serialHeader = "Question #$serialNumber: ${mistake.title}"

                    // Measure title text height
                    val titleLayout = StaticLayout.Builder.obtain(
                        serialHeader,
                        0,
                        serialHeader.length,
                        boldPaint,
                        contentWidth
                    ).build()

                    // Estimate height for this question block
                    var estimatedBlockHeight = titleLayout.height + 30f // title + badge

                    // What went wrong layout
                    val whatWentWrongText = "What Went Wrong: ${mistake.whatWentWrong}"
                    val wrongLayout = StaticLayout.Builder.obtain(
                        whatWentWrongText,
                        0,
                        whatWentWrongText.length,
                        textPaint,
                        contentWidth - 20
                    ).build()
                    estimatedBlockHeight += wrongLayout.height + 20f

                    // Correct approach layout
                    var correctLayout: StaticLayout? = null
                    if (mistake.correctApproach.isNotBlank()) {
                        val correctText = "Correct Approach & Concept: ${mistake.correctApproach}"
                        correctLayout = StaticLayout.Builder.obtain(
                            correctText,
                            0,
                            correctText.length,
                            textPaint,
                            contentWidth - 20
                        ).build()
                        estimatedBlockHeight += correctLayout.height + 16f
                    }

                    // Answer layout
                    var answerLayout: StaticLayout? = null
                    if (mistake.correctAnswer.isNotBlank()) {
                        val ansText = "Correct Final Answer: ${mistake.correctAnswer}"
                        answerLayout = StaticLayout.Builder.obtain(
                            ansText,
                            0,
                            ansText.length,
                            textPaint,
                            contentWidth - 20
                        ).build()
                        estimatedBlockHeight += answerLayout.height + 14f
                    }

                    // Photo bitmap if available
                    var questionBitmap: Bitmap? = null
                    if (!mistake.imagePath.isNullOrBlank()) {
                        val imgFile = File(mistake.imagePath)
                        if (imgFile.exists()) {
                            try {
                                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                BitmapFactory.decodeFile(imgFile.absolutePath, opts)
                                val origW = opts.outWidth
                                val origH = opts.outHeight
                                if (origW > 0 && origH > 0) {
                                    val targetW = 280
                                    val targetH = (origH * (targetW.toFloat() / origW)).toInt().coerceAtMost(200)
                                    opts.inJustDecodeBounds = false
                                    opts.inSampleSize = (origW / targetW).coerceAtLeast(1)
                                    val decoded = BitmapFactory.decodeFile(imgFile.absolutePath, opts)
                                    if (decoded != null) {
                                        questionBitmap = Bitmap.createScaledBitmap(decoded, targetW, targetH, true)
                                        estimatedBlockHeight += targetH + 15f
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }

                    estimatedBlockHeight += 24f // spacing & divider line

                    // Check if new page is needed
                    if (currentY + estimatedBlockHeight > (pageHeight - margin)) {
                        drawPageFooter(canvas, pageNumber)
                        document.finishPage(page)

                        pageNumber++
                        pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                        page = document.startPage(pageInfo)
                        canvas = page.canvas
                        currentY = margin

                        // Chapter sub-header on continuation pages
                        canvas.drawText("${subject} — ${chapter.name} (Continued)", margin, currentY + 12f, metaPaint)
                        currentY += 24f
                        canvas.drawLine(margin, currentY, pageWidth - margin, currentY, linePaint)
                        currentY += 16f
                    }

                    // Draw Serial Header & Title
                    canvas.save()
                    canvas.translate(margin, currentY)
                    titleLayout.draw(canvas)
                    canvas.restore()
                    currentY += titleLayout.height + 6f

                    // Draw Mistake Category Badge
                    val isConceptual = mistake.mistakeCategory.equals("CONCEPTUAL", ignoreCase = true)
                    val categoryLabel = if (isConceptual) "  [Conceptual Mistake]  " else "  [Careless Mistake]  "
                    val catTextPaint = TextPaint().apply {
                        isAntiAlias = true
                        textSize = 9.5f
                        typeface = Typeface.DEFAULT_BOLD
                        color = if (isConceptual) Color.rgb(190, 18, 60) else Color.rgb(180, 83, 9)
                    }
                    val badgeW = catTextPaint.measureText(categoryLabel) + 12f
                    val badgeH = 16f
                    val badgeRect = RectF(margin, currentY, margin + badgeW, currentY + badgeH)
                    canvas.drawRoundRect(badgeRect, 4f, 4f, if (isConceptual) errorBadgePaint else carelessBadgePaint)
                    canvas.drawText(categoryLabel, margin + 4f, currentY + 12f, catTextPaint)
                    currentY += badgeH + 10f

                    // Draw Photo if available
                    if (questionBitmap != null) {
                        canvas.drawBitmap(questionBitmap, margin, currentY, null)
                        currentY += questionBitmap.height + 10f
                    }

                    // Draw "What Went Wrong" card block
                    val blockPad = 8f
                    val wrongBlockH = wrongLayout.height + (blockPad * 2)
                    val wrongRect = RectF(margin, currentY, pageWidth - margin, currentY + wrongBlockH)
                    cardBgPaint.color = Color.rgb(254, 242, 242) // very light red tint
                    canvas.drawRoundRect(wrongRect, 6f, 6f, cardBgPaint)

                    canvas.save()
                    canvas.translate(margin + blockPad, currentY + blockPad)
                    wrongLayout.draw(canvas)
                    canvas.restore()
                    currentY += wrongBlockH + 8f

                    // Draw "Correct Approach" block
                    if (correctLayout != null) {
                        val correctBlockH = correctLayout.height + (blockPad * 2)
                        val correctRect = RectF(margin, currentY, pageWidth - margin, currentY + correctBlockH)
                        cardBgPaint.color = Color.rgb(239, 246, 255) // very light blue tint
                        canvas.drawRoundRect(correctRect, 6f, 6f, cardBgPaint)

                        canvas.save()
                        canvas.translate(margin + blockPad, currentY + blockPad)
                        correctLayout.draw(canvas)
                        canvas.restore()
                        currentY += correctBlockH + 8f
                    }

                    // Draw Answer if present
                    if (answerLayout != null) {
                        canvas.save()
                        canvas.translate(margin, currentY)
                        answerLayout.draw(canvas)
                        canvas.restore()
                        currentY += answerLayout.height + 8f
                    }

                    // Divider after question
                    canvas.drawLine(margin, currentY, pageWidth - margin, currentY, linePaint)
                    currentY += 18f
                }
            }

            drawPageFooter(canvas, pageNumber)
            document.finishPage(page)

            FileOutputStream(file).use { out ->
                document.writeTo(out)
            }
            document.close()

            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun openPdfFile(context: Context, file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Open Questions PDF"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun sharePdfFile(context: Context, file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                putExtra(Intent.EXTRA_TEXT, "Here is my exported study questions notebook.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Download / Share PDF"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
