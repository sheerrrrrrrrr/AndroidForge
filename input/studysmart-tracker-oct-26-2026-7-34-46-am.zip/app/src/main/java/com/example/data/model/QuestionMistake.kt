package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MistakeCategory(val displayName: String, val description: String) {
    CONCEPTUAL(
        displayName = "Conceptual Mistake",
        description = "Misunderstood underlying theory, formula principle, or rule"
    ),
    CARELESS(
        displayName = "Careless Mistake",
        description = "Arithmetic error, skipped step, sign flip, or handwriting slip"
    ),
    MISREAD_QUESTION(
        displayName = "Misread Question",
        description = "Overlooked constraints, units, or key words like 'NOT'"
    ),
    FORMULA_FORGOTTEN(
        displayName = "Formula Forgotten",
        description = "Could not recall required formula, identity, or constant"
    ),
    TIME_PRESSURE(
        displayName = "Time Pressure",
        description = "Rushed through question due to time constraints"
    ),
    OTHER(
        displayName = "Other Error",
        description = "Other specific mistake type"
    );

    companion object {
        fun fromString(value: String): MistakeCategory {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: CONCEPTUAL
        }
    }
}

enum class QuestionDifficulty {
    EASY, MEDIUM, HARD
}

enum class ReviewStatus {
    NEEDS_REVIEW,
    IN_PROGRESS,
    MASTERED
}

@Entity(tableName = "chapters")
data class Chapter(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subject: String, // "Physics", "Chemistry", "Biology"
    val name: String,
    val priority: Int = 50,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "question_mistakes")
data class QuestionMistake(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subject: String,
    val topic: String = "", // Chapter name
    val imagePath: String? = null,
    val mistakeCategory: String = MistakeCategory.CONCEPTUAL.name,
    val whatWentWrong: String,
    val correctApproach: String,
    val correctAnswer: String = "",
    val difficulty: String = QuestionDifficulty.MEDIUM.name,
    val status: String = ReviewStatus.NEEDS_REVIEW.name,
    val createdAt: Long = System.currentTimeMillis(),
    val nextReviewDate: Long = System.currentTimeMillis(),
    val reviewCount: Int = 0,
    val masteryScore: Int = 0
)

@Entity(tableName = "study_tasks")
data class StudyTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subject: String,
    val dateMillis: Long,
    val startTime: String = "10:00",
    val durationMinutes: Int = 45,
    val sessionType: String = "SELF_STUDY",
    val isCompleted: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "study_logs")
data class StudyLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val durationMinutes: Int,
    val subject: String,
    val sessionNote: String = ""
)

@Entity(tableName = "neet_mock_tests")
data class NeetMockTest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val physicsScore: Int = 0,      // Max 180
    val chemistryScore: Int = 0,    // Max 180
    val biologyScore: Int = 0,      // Max 360
    val totalScore: Int = physicsScore + chemistryScore + biologyScore, // Max 720
    val maxMarks: Int = 720,
    val carelessMistakesCount: Int = 0,   // Negative marks from silly slips (-5 marks lost per question in NEET!)
    val conceptualMistakesCount: Int = 0,
    val notes: String = ""
)
