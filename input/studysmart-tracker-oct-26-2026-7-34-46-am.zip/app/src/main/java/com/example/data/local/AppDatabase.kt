package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Chapter
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionMistake
import com.example.data.model.StudyLog
import com.example.data.model.StudyTask

@Database(
    entities = [QuestionMistake::class, StudyTask::class, StudyLog::class, Chapter::class, NeetMockTest::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun questionDao(): QuestionDao
    abstract fun studyTaskDao(): StudyTaskDao
    abstract fun studyLogDao(): StudyLogDao
    abstract fun chapterDao(): ChapterDao
    abstract fun neetMockTestDao(): NeetMockTestDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "studypulse_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
