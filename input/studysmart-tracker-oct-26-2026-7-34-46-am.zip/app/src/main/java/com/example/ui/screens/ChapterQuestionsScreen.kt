package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Chapter
import com.example.data.model.MistakeCategory
import com.example.data.model.QuestionMistake
import com.example.data.model.ReviewStatus
import com.example.ui.components.PdfExportDialog
import com.example.ui.theme.CarelessColor
import com.example.ui.theme.CarelessContainer
import com.example.ui.theme.ConceptualColor
import com.example.ui.theme.ConceptualContainer
import com.example.util.PdfExportManager
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterQuestionsScreen(
    subject: String,
    chapter: Chapter,
    allQuestions: List<QuestionMistake>,
    onQuestionClick: (QuestionMistake) -> Unit,
    onAddNewQuestion: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Filter questions that belong to this subject and chapter
    val chapterQuestions = allQuestions.filter {
        it.subject.equals(subject, ignoreCase = true) &&
                it.topic.equals(chapter.name, ignoreCase = true)
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<String?>(null) }
    var selectedStatusFilter by remember { mutableStateOf<String?>(null) }

    // PDF Export Dialog State
    var showPdfDialog by remember { mutableStateOf(false) }
    var generatedPdfFile by remember { mutableStateOf<File?>(null) }
    var isGeneratingPdf by remember { mutableStateOf(false) }

    val filteredList = chapterQuestions.filter { item ->
        val matchesQuery = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.whatWentWrong.contains(searchQuery, ignoreCase = true) ||
                item.correctApproach.contains(searchQuery, ignoreCase = true)

        val matchesCategory = selectedCategoryFilter == null || item.mistakeCategory.equals(selectedCategoryFilter, ignoreCase = true)
        val matchesStatus = selectedStatusFilter == null || item.status.equals(selectedStatusFilter, ignoreCase = true)

        matchesQuery && matchesCategory && matchesStatus
    }

    val conceptualCount = chapterQuestions.count { it.mistakeCategory == MistakeCategory.CONCEPTUAL.name }
    val carelessCount = chapterQuestions.count { it.mistakeCategory == MistakeCategory.CARELESS.name }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = chapter.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "$subject • ${chapterQuestions.size} Questions",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("button_back_to_chapters")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Chapters")
                    }
                },
                actions = {
                    // Quick PDF download from top bar
                    IconButton(
                        onClick = {
                            showPdfDialog = true
                            isGeneratingPdf = true
                            generatedPdfFile = null
                            coroutineScope.launch {
                                val file = PdfExportManager.generateChapterPdf(
                                    context = context,
                                    subject = subject,
                                    chapter = chapter,
                                    questions = chapterQuestions
                                )
                                generatedPdfFile = file
                                isGeneratingPdf = false
                            }
                        },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFDE8E8))
                            .testTag("button_topbar_export_pdf")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Export to PDF",
                            tint = Color(0xFFB42318),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewQuestion,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_question_in_chapter")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Log Mistake")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Log Mistake", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search questions in ${chapter.name}...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_chapter_questions"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == null && selectedStatusFilter == null,
                            onClick = {
                                selectedCategoryFilter = null
                                selectedStatusFilter = null
                            },
                            label = { Text("All (${chapterQuestions.size})") }
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name,
                            onClick = {
                                selectedCategoryFilter = if (selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name) null else MistakeCategory.CONCEPTUAL.name
                            },
                            label = { Text("Conceptual ($conceptualCount)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ConceptualContainer,
                                selectedLabelColor = ConceptualColor
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == MistakeCategory.CARELESS.name,
                            onClick = {
                                selectedCategoryFilter = if (selectedCategoryFilter == MistakeCategory.CARELESS.name) null else MistakeCategory.CARELESS.name
                            },
                            label = { Text("Careless ($carelessCount)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CarelessContainer,
                                selectedLabelColor = CarelessColor
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedStatusFilter == ReviewStatus.NEEDS_REVIEW.name,
                            onClick = {
                                selectedStatusFilter = if (selectedStatusFilter == ReviewStatus.NEEDS_REVIEW.name) null else ReviewStatus.NEEDS_REVIEW.name
                            },
                            label = { Text("Needs Review") }
                        )
                    }
                }
            }

            // Empty State
            if (filteredList.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No Questions Stored in ${chapter.name}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tap 'Log Mistake' to capture a photo of any question from this chapter and record whether you made a conceptual or careless error.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { mistake ->
                    QuestionMistakeCard(
                        mistake = mistake,
                        onClick = { onQuestionClick(mistake) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (showPdfDialog) {
        PdfExportDialog(
            chapter = chapter,
            subject = subject,
            generatedFile = generatedPdfFile,
            isGenerating = isGeneratingPdf,
            questionCount = chapterQuestions.size,
            onDismiss = {
                showPdfDialog = false
                generatedPdfFile = null
            }
        )
    }
}
