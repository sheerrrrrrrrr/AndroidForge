package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionMistake
import com.example.data.model.StudyTask
import com.example.ui.StudyViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun MonthlyCalendarView(
    selectedDateMillis: Long,
    onDateSelected: (Long) -> Unit,
    tasks: List<StudyTask>,
    reviewQuestions: List<QuestionMistake>,
    modifier: Modifier = Modifier
) {
    var displayCal by remember {
        mutableStateOf(Calendar.getInstance().apply { timeInMillis = selectedDateMillis })
    }

    val monthYearFormat = remember { SimpleDateFormat("MMMM yyyy", Locale.getDefault()) }
    val daysOfWeek = remember { listOf("S", "M", "T", "W", "T", "F", "S") }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("monthly_calendar_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Month Header & Navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Calendar",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = monthYearFormat.format(displayCal.time),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            val prev = Calendar.getInstance().apply {
                                timeInMillis = displayCal.timeInMillis
                                add(Calendar.MONTH, -1)
                            }
                            displayCal = prev
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("calendar_prev_month")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Previous Month",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            val now = System.currentTimeMillis()
                            displayCal = Calendar.getInstance().apply { timeInMillis = now }
                            onDateSelected(now)
                        },
                        modifier = Modifier
                            .height(32.dp)
                            .padding(horizontal = 4.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text("Today", fontSize = 12.sp)
                    }

                    IconButton(
                        onClick = {
                            val next = Calendar.getInstance().apply {
                                timeInMillis = displayCal.timeInMillis
                                add(Calendar.MONTH, 1)
                            }
                            displayCal = next
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("calendar_next_month")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next Month",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Day of Week Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                daysOfWeek.forEach { dayName ->
                    Text(
                        text = dayName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Days Grid
            val daysInMonth = remember(displayCal) {
                calculateDaysForMonth(displayCal)
            }

            val todayCal = remember { Calendar.getInstance() }
            val selectedCal = remember(selectedDateMillis) {
                Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
            }

            // Render weeks (up to 6 rows)
            daysInMonth.chunked(7).forEach { week ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    week.forEach { dayInfo ->
                        val isSelected = dayInfo.isInCurrentMonth &&
                                dayInfo.year == selectedCal.get(Calendar.YEAR) &&
                                dayInfo.month == selectedCal.get(Calendar.MONTH) &&
                                dayInfo.day == selectedCal.get(Calendar.DAY_OF_MONTH)

                        val isToday = dayInfo.isInCurrentMonth &&
                                dayInfo.year == todayCal.get(Calendar.YEAR) &&
                                dayInfo.month == todayCal.get(Calendar.MONTH) &&
                                dayInfo.day == todayCal.get(Calendar.DAY_OF_MONTH)

                        val dayStart = dayInfo.startOfDayMillis
                        val dayEnd = dayStart + (24L * 60 * 60 * 1000) - 1

                        val hasTasks = tasks.any { it.dateMillis in dayStart..dayEnd }
                        val hasReviews = reviewQuestions.any { it.nextReviewDate in dayStart..dayEnd }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .then(
                                    when {
                                        isSelected -> Modifier.background(MaterialTheme.colorScheme.primary)
                                        isToday -> Modifier
                                            .border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                                        else -> Modifier
                                    }
                                )
                                .clickable(enabled = dayInfo.isInCurrentMonth) {
                                    val target = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, dayInfo.year)
                                        set(Calendar.MONTH, dayInfo.month)
                                        set(Calendar.DAY_OF_MONTH, dayInfo.day)
                                    }
                                    onDateSelected(target.timeInMillis)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = dayInfo.day.toString(),
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                    color = when {
                                        isSelected -> MaterialTheme.colorScheme.onPrimary
                                        !dayInfo.isInCurrentMonth -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                                        isToday -> MaterialTheme.colorScheme.primary
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                                // Event Indicator Dots
                                if (dayInfo.isInCurrentMonth && (hasTasks || hasReviews)) {
                                    Row(
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 1.dp)
                                    ) {
                                        if (hasTasks) {
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.onPrimary
                                                        else MaterialTheme.colorScheme.secondary
                                                    )
                                            )
                                        }
                                        if (hasTasks && hasReviews) {
                                            Spacer(modifier = Modifier.width(2.dp))
                                        }
                                        if (hasReviews) {
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (isSelected) Color(0xFFFCD34D)
                                                        else Color(0xFFE11D48)
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Calendar legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Study Tasks", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(16.dp))
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE11D48))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Question Reviews Due", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun StudyTaskItemCard(
    task: StudyTask,
    onToggleCompleted: (StudyTask) -> Unit,
    onDelete: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("study_task_${task.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (task.isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggleCompleted(task) },
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("task_checkbox_${task.id}")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (task.isCompleted)
                        MaterialTheme.colorScheme.onSurfaceVariant
                    else
                        MaterialTheme.colorScheme.onSurface
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = task.subject,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${task.startTime} • ${task.durationMinutes} min",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (task.notes.isNotBlank()) {
                    Text(
                        text = task.notes,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp),
                        maxLines = 2
                    )
                }
            }

            IconButton(
                onClick = { onDelete(task.id) },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Task",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

data class DayInfo(
    val year: Int,
    val month: Int,
    val day: Int,
    val isInCurrentMonth: Boolean,
    val startOfDayMillis: Long
)

fun calculateDaysForMonth(currentCal: Calendar): List<DayInfo> {
    val result = mutableListOf<DayInfo>()
    val cal = Calendar.getInstance().apply {
        timeInMillis = currentCal.timeInMillis
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    val currentYear = cal.get(Calendar.YEAR)
    val currentMonth = cal.get(Calendar.MONTH)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday
    val maxDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    // Previous month padding
    val prevMonthCal = Calendar.getInstance().apply {
        timeInMillis = cal.timeInMillis
        add(Calendar.MONTH, -1)
    }
    val prevMonthDays = prevMonthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val leadingDays = firstDayOfWeek - 1

    for (i in (prevMonthDays - leadingDays + 1)..prevMonthDays) {
        val prevDayCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, prevMonthCal.get(Calendar.YEAR))
            set(Calendar.MONTH, prevMonthCal.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, i)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        result.add(
            DayInfo(
                year = prevMonthCal.get(Calendar.YEAR),
                month = prevMonthCal.get(Calendar.MONTH),
                day = i,
                isInCurrentMonth = false,
                startOfDayMillis = prevDayCal.timeInMillis
            )
        )
    }

    // Current month days
    for (i in 1..maxDaysInMonth) {
        val thisDayCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
            set(Calendar.DAY_OF_MONTH, i)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        result.add(
            DayInfo(
                year = currentYear,
                month = currentMonth,
                day = i,
                isInCurrentMonth = true,
                startOfDayMillis = thisDayCal.timeInMillis
            )
        )
    }

    // Trailing days to fill full grid (up to 35 or 42 cells)
    val totalCells = if (result.size > 35) 42 else 35
    val trailingDays = totalCells - result.size
    val nextMonthCal = Calendar.getInstance().apply {
        timeInMillis = cal.timeInMillis
        add(Calendar.MONTH, 1)
    }

    for (i in 1..trailingDays) {
        val nextDayCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, nextMonthCal.get(Calendar.YEAR))
            set(Calendar.MONTH, nextMonthCal.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, i)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        result.add(
            DayInfo(
                year = nextMonthCal.get(Calendar.YEAR),
                month = nextMonthCal.get(Calendar.MONTH),
                day = i,
                isInCurrentMonth = false,
                startOfDayMillis = nextDayCal.timeInMillis
            )
        )
    }

    return result
}
