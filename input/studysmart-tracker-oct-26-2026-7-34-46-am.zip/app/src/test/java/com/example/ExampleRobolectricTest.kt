package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Chapter
import com.example.data.model.MistakeCategory
import com.example.data.model.NeetMockTest
import com.example.data.model.QuestionDifficulty
import com.example.data.model.QuestionMistake
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("StudyPulse", appName)
    }

    @Test
    fun `test mistake category parsing`() {
        assertEquals(MistakeCategory.CONCEPTUAL, MistakeCategory.fromString("CONCEPTUAL"))
        assertEquals(MistakeCategory.CARELESS, MistakeCategory.fromString("CARELESS"))
        assertEquals(MistakeCategory.MISREAD_QUESTION, MistakeCategory.fromString("MISREAD_QUESTION"))
    }

    @Test
    fun `test question mistake model`() {
        val question = QuestionMistake(
            title = "Test Mechanics",
            subject = "Physics",
            topic = "Kinematics",
            whatWentWrong = "Forgot negative sign",
            correctApproach = "Apply chain rule",
            mistakeCategory = MistakeCategory.CARELESS.name,
            difficulty = QuestionDifficulty.EASY.name
        )
        assertEquals("Physics", question.subject)
        assertEquals("Kinematics", question.topic)
        assertEquals("CARELESS", question.mistakeCategory)
        assertEquals(0, question.reviewCount)
    }

    @Test
    fun `test chapter model`() {
        val chapter = Chapter(subject = "Physics", name = "Thermodynamics")
        assertEquals("Physics", chapter.subject)
        assertEquals("Thermodynamics", chapter.name)
    }

    @Test
    fun `test neet mock test model`() {
        val mock = NeetMockTest(
            title = "NEET Full Mock 1",
            physicsScore = 140,
            chemistryScore = 150,
            biologyScore = 320,
            carelessMistakesCount = 4
        )
        assertEquals(610, mock.totalScore)
        assertEquals(140, mock.physicsScore)
        assertEquals(150, mock.chemistryScore)
        assertEquals(320, mock.biologyScore)
        assertEquals(4, mock.carelessMistakesCount)
    }
}
