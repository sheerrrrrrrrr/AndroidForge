package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MistakeCategory
import com.example.data.model.QuestionDifficulty
import com.example.data.model.ReviewStatus
import com.example.ui.theme.CarelessColor
import com.example.ui.theme.CarelessContainer
import com.example.ui.theme.ConceptualColor
import com.example.ui.theme.ConceptualContainer
import com.example.ui.theme.FormulaColor
import com.example.ui.theme.FormulaContainer
import com.example.ui.theme.MasteredGreen
import com.example.ui.theme.MasteredGreenContainer
import com.example.ui.theme.MisreadColor
import com.example.ui.theme.MisreadContainer
import com.example.ui.theme.TimePressureColor
import com.example.ui.theme.TimePressureContainer

data class CategoryStyle(
    val color: Color,
    val containerColor: Color,
    val icon: ImageVector,
    val label: String
)

fun getCategoryStyle(categoryName: String): CategoryStyle {
    val category = MistakeCategory.fromString(categoryName)
    return when (category) {
        MistakeCategory.CONCEPTUAL -> CategoryStyle(
            color = ConceptualColor,
            containerColor = ConceptualContainer,
            icon = Icons.Default.Lightbulb,
            label = "Conceptual"
        )
        MistakeCategory.CARELESS -> CategoryStyle(
            color = CarelessColor,
            containerColor = CarelessContainer,
            icon = Icons.Default.Calculate,
            label = "Careless Error"
        )
        MistakeCategory.MISREAD_QUESTION -> CategoryStyle(
            color = MisreadColor,
            containerColor = MisreadContainer,
            icon = Icons.Default.VisibilityOff,
            label = "Misread"
        )
        MistakeCategory.FORMULA_FORGOTTEN -> CategoryStyle(
            color = FormulaColor,
            containerColor = FormulaContainer,
            icon = Icons.Default.MenuBook,
            label = "Formula"
        )
        MistakeCategory.TIME_PRESSURE -> CategoryStyle(
            color = TimePressureColor,
            containerColor = TimePressureContainer,
            icon = Icons.Default.Schedule,
            label = "Time Pressure"
        )
        MistakeCategory.OTHER -> CategoryStyle(
            color = Color(0xFF475569),
            containerColor = Color(0xFFE2E8F0),
            icon = Icons.Default.HelpOutline,
            label = "Other"
        )
    }
}

@Composable
fun MistakeCategoryBadge(
    categoryName: String,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val style = getCategoryStyle(categoryName)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(style.containerColor)
            .padding(horizontal = if (compact) 6.dp else 10.dp, vertical = if (compact) 3.dp else 5.dp)
            .testTag("category_badge_${categoryName.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = style.icon,
                contentDescription = style.label,
                tint = style.color,
                modifier = Modifier.size(if (compact) 12.dp else 14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = style.label,
                color = style.color,
                fontSize = if (compact) 11.sp else 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun ReviewStatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (color, container, label, icon) = when (status) {
        ReviewStatus.MASTERED.name -> Quad(
            MasteredGreen,
            MasteredGreenContainer,
            "Mastered",
            Icons.Default.CheckCircle
        )
        ReviewStatus.IN_PROGRESS.name -> Quad(
            Color(0xFF0284C7),
            Color(0xFFE0F2FE),
            "Practicing",
            Icons.Default.Warning
        )
        else -> Quad(
            Color(0xFFDC2626),
            Color(0xFFFEE2E2),
            "Needs Review",
            Icons.Default.HelpOutline
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(container)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun DifficultyBadge(
    difficulty: String,
    modifier: Modifier = Modifier
) {
    val (text, color) = when (difficulty) {
        QuestionDifficulty.HARD.name -> "Hard" to Color(0xFFEF4444)
        QuestionDifficulty.MEDIUM.name -> "Med" to Color(0xFFF59E0B)
        else -> "Easy" to Color(0xFF10B981)
    }

    Text(
        text = text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
