package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun AddChapterDialog(
    subject: String,
    onDismiss: () -> Unit,
    onAddChapter: (String, Int) -> Unit
) {
    var chapterName by remember { mutableStateOf("") }
    var priorityValue by remember { mutableFloatStateOf(60f) } // default priority
    var showError by remember { mutableStateOf(false) }

    val currentPriority = priorityValue.roundToInt().coerceIn(1, 100)

    val placeholder = when (subject.lowercase()) {
        "physics" -> "e.g. Kinematics, Thermodynamics, Electromagnetism, Optics"
        "chemistry" -> "e.g. Chemical Bonding, Organic Chemistry, Thermodynamics"
        "biology" -> "e.g. Cell Structure, Genetics, Plant Physiology, Ecology"
        else -> "e.g. Chapter name"
    }

    val priorityDescriptor = when {
        currentPriority >= 85 -> "Crucial (High Weightage in NEET)"
        currentPriority >= 70 -> "High Priority"
        currentPriority >= 40 -> "Medium Priority"
        else -> "Low Priority"
    }

    val priorityColor = when {
        currentPriority >= 85 -> Color(0xFFC05621)
        currentPriority >= 70 -> Color(0xFFD97706)
        currentPriority >= 40 -> Color(0xFF4338CA)
        else -> Color(0xFF6B7280)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Add Chapter in $subject",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Store a chapter or unit under $subject to organize your missed questions:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = chapterName,
                    onValueChange = { chapterName = it },
                    label = { Text("Chapter / Unit Name *") },
                    placeholder = { Text(placeholder) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_chapter_name"),
                    isError = showError && chapterName.isBlank(),
                    supportingText = {
                        if (showError && chapterName.isBlank()) {
                            Text("Chapter name cannot be empty", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Chapter Priority Section (1 to 100)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = priorityColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Chapter Priority:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(priorityColor.copy(alpha = 0.12f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "$currentPriority / 100",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = priorityColor
                        )
                    }
                }

                Text(
                    text = priorityDescriptor,
                    fontSize = 12.sp,
                    color = priorityColor,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Slider(
                    value = priorityValue,
                    onValueChange = { priorityValue = it },
                    valueRange = 1f..100f,
                    steps = 98,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("slider_chapter_priority"),
                    colors = SliderDefaults.colors(
                        thumbColor = priorityColor,
                        activeTrackColor = priorityColor
                    )
                )

                // Quick priority presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(25, 50, 75, 95).forEach { preset ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    1.dp,
                                    if (currentPriority == preset) priorityColor else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(8.dp)
                                )
                                .background(
                                    if (currentPriority == preset) priorityColor.copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .clickable { priorityValue = preset.toFloat() }
                                .padding(vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$preset",
                                fontSize = 11.sp,
                                fontWeight = if (currentPriority == preset) FontWeight.Bold else FontWeight.Normal,
                                color = if (currentPriority == preset) priorityColor else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (chapterName.isBlank()) {
                        showError = true
                        return@Button
                    }
                    onAddChapter(chapterName.trim(), currentPriority)
                    onDismiss()
                },
                modifier = Modifier.testTag("button_save_chapter")
            ) {
                Text("Add Chapter")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
