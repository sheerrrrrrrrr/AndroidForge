package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.QuestionMistake
import com.example.ui.components.AddChapterDialog
import com.example.ui.components.AddEditQuestionDialog
import com.example.ui.components.AddStudyTaskDialog
import com.example.ui.components.FocusTimerDialog
import com.example.ui.components.QuestionDetailDialog
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.ChapterQuestionsScreen
import com.example.ui.screens.ChaptersScreen
import com.example.ui.screens.PracticeReviewScreen
import com.example.ui.screens.SubjectsScreen

enum class MainTab(val title: String, val icon: ImageVector) {
    QUESTIONS("Subjects", Icons.Default.MenuBook),
    CALENDAR("Calendar", Icons.Default.CalendarMonth),
    REVIEW("Practice", Icons.Default.Psychology),
    ANALYTICS("Analytics", Icons.Default.Insights)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: StudyViewModel) {
    var selectedTab by remember { mutableStateOf(MainTab.QUESTIONS) }

    // Dialog state holders
    var showAddQuestionDialog by remember { mutableStateOf(false) }
    var showAddChapterDialog by remember { mutableStateOf(false) }
    var questionToEdit by remember { mutableStateOf<QuestionMistake?>(null) }
    var questionToInspect by remember { mutableStateOf<QuestionMistake?>(null) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showFocusTimerDialog by remember { mutableStateOf(false) }

    // State collections
    val allMistakes by viewModel.allMistakes.collectAsStateWithLifecycle()
    val allChapters by viewModel.allChapters.collectAsStateWithLifecycle()
    val allTasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val tasksForSelectedDate by viewModel.tasksForSelectedDate.collectAsStateWithLifecycle()
    val selectedDateMillis by viewModel.selectedDateMillis.collectAsStateWithLifecycle()
    val reviewDueQuestions by viewModel.reviewDueQuestions.collectAsStateWithLifecycle()
    val studyLogs by viewModel.allLogs.collectAsStateWithLifecycle()
    val totalStudyMinutes by viewModel.totalStudyMinutes.collectAsStateWithLifecycle()
    val neetMockTests by viewModel.neetMockTests.collectAsStateWithLifecycle()

    // Hierarchical navigation states for the Subjects & Chapters flow
    val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
    val selectedChapter by viewModel.selectedChapter.collectAsStateWithLifecycle()

    val showMainTopBar = selectedTab != MainTab.QUESTIONS || selectedSubject == null

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (showMainTopBar) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "StudyPulse",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Study streak badge
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFF4ECE2))
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalFireDepartment,
                                    contentDescription = "Streak",
                                    tint = Color(0xFFC05621),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "5d streak",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF78350F)
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showFocusTimerDialog = true },
                            modifier = Modifier.testTag("top_bar_focus_timer")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Focus Timer",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                MainTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            if (tab == MainTab.REVIEW && reviewDueQuestions.isNotEmpty()) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = Color(0xFFE11D48)) {
                                            Text("${reviewDueQuestions.size}")
                                        }
                                    }
                                ) {
                                    Icon(imageVector = tab.icon, contentDescription = tab.title)
                                }
                            } else {
                                Icon(imageVector = tab.icon, contentDescription = tab.title)
                            }
                        },
                        label = { Text(tab.title, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                MainTab.QUESTIONS -> {
                    // Hierarchical view: Subjects -> Chapters -> Questions in Chapter
                    val currentSubject = selectedSubject
                    val currentChapter = selectedChapter

                    when {
                        currentSubject == null -> {
                            // Level 1: 3 Subjects (Physics, Chemistry, Biology)
                            SubjectsScreen(
                                chapters = allChapters,
                                mistakes = allMistakes,
                                onSelectSubject = { subjectName ->
                                    viewModel.selectSubject(subjectName)
                                }
                            )
                        }
                        currentChapter == null -> {
                            // Level 2: Chapters inside the selected Subject
                            ChaptersScreen(
                                subject = currentSubject,
                                chapters = allChapters,
                                allMistakes = allMistakes,
                                onSelectChapter = { chapter ->
                                    viewModel.selectChapter(chapter)
                                },
                                onAddChapter = { showAddChapterDialog = true },
                                onUpdatePriority = { chapter, priority -> viewModel.updateChapterPriority(chapter, priority) },
                                onDeleteChapter = { chapter ->
                                    viewModel.deleteChapter(chapter)
                                },
                                onBack = { viewModel.selectSubject(null) }
                            )
                        }
                        else -> {
                            // Level 3: Questions stored inside the selected Chapter
                            ChapterQuestionsScreen(
                                subject = currentSubject,
                                chapter = currentChapter,
                                allQuestions = allMistakes,
                                onQuestionClick = { mistake ->
                                    questionToInspect = mistake
                                },
                                onAddNewQuestion = { showAddQuestionDialog = true },
                                onBack = { viewModel.selectChapter(null) }
                            )
                        }
                    }
                }

                MainTab.CALENDAR -> {
                    CalendarScreen(
                        selectedDateMillis = selectedDateMillis,
                        onDateSelected = { viewModel.setSelectedDate(it) },
                        allTasks = allTasks,
                        tasksForSelectedDate = tasksForSelectedDate,
                        allMistakes = allMistakes,
                        onToggleTaskCompleted = { viewModel.toggleTaskCompleted(it) },
                        onDeleteTask = { viewModel.deleteTask(it) },
                        onScheduleNewTask = { showAddTaskDialog = true },
                        onOpenFocusTimer = { showFocusTimerDialog = true },
                        onQuestionReviewClick = { questionToInspect = it }
                    )
                }

                MainTab.REVIEW -> {
                    PracticeReviewScreen(
                        questionsDue = reviewDueQuestions,
                        allQuestions = allMistakes,
                        onRecordReview = { mistake, gotItRight ->
                            viewModel.recordReview(mistake, gotItRight)
                        }
                    )
                }

                MainTab.ANALYTICS -> {
                    AnalyticsScreen(
                        mistakes = allMistakes,
                        tasks = allTasks,
                        studyLogs = studyLogs,
                        neetMockTests = neetMockTests,
                        totalStudyMinutes = totalStudyMinutes ?: 0,
                        onLogNeetMock = { title, phy, chem, bio, careless, conceptual, notes ->
                            viewModel.logNeetMockTest(
                                title = title,
                                physicsScore = phy,
                                chemistryScore = chem,
                                biologyScore = bio,
                                carelessMistakesCount = careless,
                                conceptualMistakesCount = conceptual,
                                notes = notes
                            )
                        },
                        onDeleteNeetMock = { viewModel.deleteNeetMockTest(it) }
                    )
                }
            }
        }
    }

    // Dialog: Add Chapter inside selected subject
    if (showAddChapterDialog && selectedSubject != null) {
        AddChapterDialog(
            subject = selectedSubject!!,
            onDismiss = { showAddChapterDialog = false },
            onAddChapter = { chapterName, priority ->
                viewModel.addChapter(selectedSubject!!, chapterName, priority)
            }
        )
    }

    // Dialog: Add New Question
    if (showAddQuestionDialog) {
        val currentSub = selectedSubject ?: "Physics"
        val currentChap = selectedChapter?.name
        val chaptersForSub = allChapters
            .filter { it.subject.equals(currentSub, ignoreCase = true) }
            .map { it.name }

        AddEditQuestionDialog(
            questionToEdit = null,
            presetSubject = currentSub,
            presetTopic = currentChap,
            availableChapters = chaptersForSub,
            onDismiss = { showAddQuestionDialog = false },
            onSave = { title, subject, topic, category, whatWentWrong, correctApproach, correctAnswer, difficulty, imageUri ->
                viewModel.addQuestion(
                    title,
                    subject,
                    topic,
                    category,
                    whatWentWrong,
                    correctApproach,
                    correctAnswer,
                    difficulty,
                    imageUri
                )
            }
        )
    }

    // Dialog: Edit Existing Question
    questionToEdit?.let { mistake ->
        val chaptersForSub = allChapters
            .filter { it.subject.equals(mistake.subject, ignoreCase = true) }
            .map { it.name }

        AddEditQuestionDialog(
            questionToEdit = mistake,
            presetSubject = mistake.subject,
            presetTopic = mistake.topic,
            availableChapters = chaptersForSub,
            onDismiss = { questionToEdit = null },
            onSave = { title, subject, topic, category, whatWentWrong, correctApproach, correctAnswer, difficulty, imageUri ->
                viewModel.updateQuestion(
                    id = mistake.id,
                    title = title,
                    subject = subject,
                    topic = topic,
                    mistakeCategory = category,
                    whatWentWrong = whatWentWrong,
                    correctApproach = correctApproach,
                    correctAnswer = correctAnswer,
                    difficulty = difficulty,
                    newImageUri = imageUri,
                    existingImagePath = mistake.imagePath
                )
                questionToEdit = null
            }
        )
    }

    // Dialog: Inspect Question Details
    questionToInspect?.let { mistake ->
        QuestionDetailDialog(
            mistake = mistake,
            onDismiss = { questionToInspect = null },
            onEdit = {
                questionToInspect = null
                questionToEdit = it
            },
            onDelete = {
                viewModel.deleteQuestion(it)
                questionToInspect = null
            },
            onRecordReview = { item, gotItRight ->
                viewModel.recordReview(item, gotItRight)
            }
        )
    }

    // Dialog: Add Study Task on Calendar
    if (showAddTaskDialog) {
        AddStudyTaskDialog(
            initialDateMillis = selectedDateMillis,
            onDismiss = { showAddTaskDialog = false },
            onSaveTask = { title, subject, dateMillis, startTime, durationMinutes, sessionType, notes ->
                viewModel.addStudyTask(
                    title,
                    subject,
                    dateMillis,
                    startTime,
                    durationMinutes,
                    sessionType,
                    notes
                )
            }
        )
    }

    // Dialog: Focus Timer / Pomodoro
    if (showFocusTimerDialog) {
        FocusTimerDialog(
            onDismiss = { showFocusTimerDialog = false },
            onLogSession = { minutes, subject, notes ->
                viewModel.logCompletedStudySession(minutes, subject, notes)
            }
        )
    }
}
