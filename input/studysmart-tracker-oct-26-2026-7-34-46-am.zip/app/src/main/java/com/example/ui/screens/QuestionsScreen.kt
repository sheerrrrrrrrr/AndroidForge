package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.MistakeCategory
import com.example.data.model.QuestionMistake
import com.example.data.model.ReviewStatus
import com.example.ui.components.DifficultyBadge
import com.example.ui.components.MistakeCategoryBadge
import com.example.ui.components.ReviewStatusBadge
import com.example.ui.theme.CarelessColor
import com.example.ui.theme.CarelessContainer
import com.example.ui.theme.ConceptualColor
import com.example.ui.theme.ConceptualContainer
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuestionsScreen(
    questions: List<QuestionMistake>,
    allQuestions: List<QuestionMistake>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedCategoryFilter: String?,
    onCategoryFilterChange: (String?) -> Unit,
    selectedStatusFilter: String?,
    onStatusFilterChange: (String?) -> Unit,
    onQuestionClick: (QuestionMistake) -> Unit,
    onAddNewQuestion: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalCount = allQuestions.size
    val conceptualCount = allQuestions.count { it.mistakeCategory == MistakeCategory.CONCEPTUAL.name }
    val carelessCount = allQuestions.count { it.mistakeCategory == MistakeCategory.CARELESS.name }
    val masteredCount = allQuestions.count { it.status == ReviewStatus.MASTERED.name }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewQuestion,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_question")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Question")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Log Mistake", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Stats Quick Banner
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Conceptual Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onCategoryFilterChange(
                                    if (selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name) null
                                    else MistakeCategory.CONCEPTUAL.name
                                )
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name)
                                ConceptualContainer
                            else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = ConceptualColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Conceptual", fontSize = 11.sp, color = ConceptualColor, fontWeight = FontWeight.SemiBold)
                            }
                            Text(
                                text = "$conceptualCount",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Careless Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onCategoryFilterChange(
                                    if (selectedCategoryFilter == MistakeCategory.CARELESS.name) null
                                    else MistakeCategory.CARELESS.name
                                )
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedCategoryFilter == MistakeCategory.CARELESS.name)
                                CarelessContainer
                            else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = CarelessColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Careless", fontSize = 11.sp, color = CarelessColor, fontWeight = FontWeight.SemiBold)
                            }
                            Text(
                                text = "$carelessCount",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Mastered Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onStatusFilterChange(
                                    if (selectedStatusFilter == ReviewStatus.MASTERED.name) null
                                    else ReviewStatus.MASTERED.name
                                )
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedStatusFilter == ReviewStatus.MASTERED.name)
                                Color(0xFFDCFCE7)
                            else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Mastered", fontSize = 11.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "$masteredCount / $totalCount",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search by question, formula, or subject...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_questions_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )
            }

            // Filter Chips Bar
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == null && selectedStatusFilter == null,
                            onClick = {
                                onCategoryFilterChange(null)
                                onStatusFilterChange(null)
                            },
                            label = { Text("All (${allQuestions.size})") }
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name,
                            onClick = {
                                onCategoryFilterChange(
                                    if (selectedCategoryFilter == MistakeCategory.CONCEPTUAL.name) null
                                    else MistakeCategory.CONCEPTUAL.name
                                )
                            },
                            label = { Text("Conceptual ($conceptualCount)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ConceptualContainer,
                                selectedLabelColor = ConceptualColor
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == MistakeCategory.CARELESS.name,
                            onClick = {
                                onCategoryFilterChange(
                                    if (selectedCategoryFilter == MistakeCategory.CARELESS.name) null
                                    else MistakeCategory.CARELESS.name
                                )
                            },
                            label = { Text("Careless ($carelessCount)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CarelessContainer,
                                selectedLabelColor = CarelessColor
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = selectedStatusFilter == ReviewStatus.NEEDS_REVIEW.name,
                            onClick = {
                                onStatusFilterChange(
                                    if (selectedStatusFilter == ReviewStatus.NEEDS_REVIEW.name) null
                                    else ReviewStatus.NEEDS_REVIEW.name
                                )
                            },
                            label = { Text("Needs Review") }
                        )
                    }
                }
            }

            // Empty State
            if (questions.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No questions match your filter",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tap 'Log Mistake' to capture photos of questions you missed and record whether the error was conceptual or careless.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(questions, key = { it.id }) { item ->
                    QuestionMistakeCard(
                        mistake = item,
                        onClick = { onQuestionClick(item) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // padding for FAB
            }
        }
    }
}

@Composable
fun QuestionMistakeCard(
    mistake: QuestionMistake,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("question_card_${mistake.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header row: Subject, Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = mistake.subject,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MistakeCategoryBadge(categoryName = mistake.mistakeCategory, compact = true)
                    DifficultyBadge(difficulty = mistake.difficulty)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Body: Thumbnail + Title & What Went Wrong
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                if (!mistake.imagePath.isNullOrBlank()) {
                    val file = File(mistake.imagePath)
                    if (file.exists()) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(file)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "Question Image Thumbnail",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = mistake.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (mistake.topic.isNotBlank()) {
                        Text(
                            text = mistake.topic,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Mistake: ${mistake.whatWentWrong}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom row: Mastery bar & review status
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Mastery",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    LinearProgressIndicator(
                        progress = { mistake.masteryScore / 100f },
                        modifier = Modifier
                            .width(80.dp)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = when {
                            mistake.masteryScore >= 80 -> Color(0xFF16A34A)
                            mistake.masteryScore >= 40 -> MaterialTheme.colorScheme.primary
                            else -> Color(0xFFDC2626)
                        }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${mistake.masteryScore}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                ReviewStatusBadge(status = mistake.status)
            }
        }
    }
}
