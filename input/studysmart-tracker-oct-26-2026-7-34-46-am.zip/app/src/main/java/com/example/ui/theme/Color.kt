package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Minimalist Warm Crème Palette
val CremeBackground = Color(0xFFFAF7F2)       // Warm Creme / Milk Linen
val CremeSurface = Color(0xFFFFFFFF)          // Pure Warm White
val CremeSurfaceVariant = Color(0xFFF3ECE1)   // Soft Ecru / Oat
val CremeOutline = Color(0xFFE7DFD3)          // Subtle Linen Border
val CremeOutlineVariant = Color(0xFFEFE8DD)   // Ultra soft divider

// Editorial Text Colors (Warm Charcoal Espresso instead of harsh pure black)
val EspressoText = Color(0xFF28231F)
val StoneSubtext = Color(0xFF6E675F)
val LightMutedText = Color(0xFF9E9589)

// Primary & Accent Tones (Minimalist Walnut & Warm Caramel)
val PrimaryEspresso = Color(0xFF382E2B)
val OnPrimaryEspresso = Color(0xFFFFFFFF)
val PrimaryContainerCreme = Color(0xFFEFE6D8)
val OnPrimaryContainerCreme = Color(0xFF2B221F)

val SecondaryStone = Color(0xFF635A52)
val OnSecondaryStone = Color(0xFFFFFFFF)
val SecondaryContainerStone = Color(0xFFE9E2D8)
val OnSecondaryContainerStone = Color(0xFF26211C)

val TertiaryWarmLatte = Color(0xFF8C6D53)
val OnTertiaryWarmLatte = Color(0xFFFFFFFF)
val TertiaryContainerLatte = Color(0xFFF4ECE2)
val OnTertiaryContainerLatte = Color(0xFF332316)

// Muted, Tasteful Category Badges (No harsh neon, soft editorial watercolor tints)
val ConceptualColor = Color(0xFFB42318)       // Elegant Terracotta Crimson
val ConceptualContainer = Color(0xFFFDE8E8)

val CarelessColor = Color(0xFFC05621)         // Warm Clay Amber
val CarelessContainer = Color(0xFFFDF0E7)

val MisreadColor = Color(0xFF6941C6)          // Muted Iris Violet
val MisreadContainer = Color(0xFFF4F0FD)

val FormulaColor = Color(0xFF175CD3)          // Oxford Slate Blue
val FormulaContainer = Color(0xFFEFF4FF)

val TimePressureColor = Color(0xFF0E7090)     // Muted Deep Ocean Teal
val TimePressureContainer = Color(0xFFECFDFF)

val MasteredGreen = Color(0xFF2D6A4F)         // Calming Sage / Forest Green
val MasteredGreenContainer = Color(0xFFEBF6F0)

// Physics, Chemistry, Biology Subject Badges (Minimalist Aesthetic)
val PhysicsSubjectColor = Color(0xFF1E3A8A)
val PhysicsContainerColor = Color(0xFFEBF1FD)

val ChemistrySubjectColor = Color(0xFF0F766E)
val ChemistryContainerColor = Color(0xFFE6F5F3)

val BiologySubjectColor = Color(0xFF2E7D32)
val BiologyContainerColor = Color(0xFFEAF5EB)
