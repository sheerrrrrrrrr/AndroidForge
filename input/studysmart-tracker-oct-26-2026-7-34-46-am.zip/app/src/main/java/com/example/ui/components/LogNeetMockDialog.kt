package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CarelessColor
import com.example.ui.theme.CremeOutline
import com.example.ui.theme.CremeSurface
import com.example.ui.theme.CremeSurfaceVariant
import com.example.ui.theme.EspressoText
import com.example.ui.theme.PrimaryEspresso
import com.example.ui.theme.StoneSubtext

@Composable
fun LogNeetMockDialog(
    onDismiss: () -> Unit,
    onSaveTest: (
        title: String,
        physicsScore: Int,
        chemistryScore: Int,
        biologyScore: Int,
        carelessMistakesCount: Int,
        conceptualMistakesCount: Int,
        notes: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var physicsText by remember { mutableStateOf("") }
    var chemistryText by remember { mutableStateOf("") }
    var biologyText by remember { mutableStateOf("") }
    var carelessText by remember { mutableStateOf("") }
    var conceptualText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val physicsScore = physicsText.toIntOrNull()?.coerceIn(0, 180) ?: 0
    val chemistryScore = chemistryText.toIntOrNull()?.coerceIn(0, 180) ?: 0
    val biologyScore = biologyText.toIntOrNull()?.coerceIn(0, 360) ?: 0
    val carelessCount = carelessText.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val conceptualCount = conceptualText.toIntOrNull()?.coerceAtLeast(0) ?: 0

    val totalScore = physicsScore + chemistryScore + biologyScore
    val potentialScore = (totalScore + (carelessCount * 5)).coerceAtMost(720)

    var showError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CremeSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Log NEET Mock Test",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = EspressoText
                    )
                    Text(
                        text = "Total Marks: 720 (P: 180, C: 180, B: 360)",
                        fontSize = 11.sp,
                        color = StoneSubtext
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = StoneSubtext)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Live Total Score Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CremeSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CremeOutline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Mock Score", fontSize = 11.sp, color = StoneSubtext, fontWeight = FontWeight.SemiBold)
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "$totalScore",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (totalScore >= 600) MaterialTheme.colorScheme.primary else EspressoText
                                )
                                Text(" / 720", fontSize = 13.sp, color = StoneSubtext)
                            }
                        }

                        if (carelessCount > 0) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("With 0 Silly Slips", fontSize = 10.sp, color = CarelessColor, fontWeight = FontWeight.SemiBold)
                                Text("$potentialScore / 720", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CarelessColor)
                                Text("(+${carelessCount * 5} marks lost)", fontSize = 10.sp, color = StoneSubtext)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Test Name
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Mock Test Name *") },
                    placeholder = { Text("e.g. Full Mock 3 - Allen / Aakash") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_mock_title"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryEspresso,
                        unfocusedBorderColor = CremeOutline
                    ),
                    isError = showError && title.isBlank(),
                    supportingText = {
                        if (showError && title.isBlank()) {
                            Text("Test title is required", color = MaterialTheme.colorScheme.error)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Subject Scores Row
                Text("Subject-Wise Scores", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EspressoText)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = physicsText,
                        onValueChange = { if (it.length <= 3) physicsText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Phy (/180)") },
                        placeholder = { Text("130") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_mock_physics"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEspresso,
                            unfocusedBorderColor = CremeOutline
                        )
                    )

                    OutlinedTextField(
                        value = chemistryText,
                        onValueChange = { if (it.length <= 3) chemistryText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Chem (/180)") },
                        placeholder = { Text("145") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_mock_chemistry"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEspresso,
                            unfocusedBorderColor = CremeOutline
                        )
                    )

                    OutlinedTextField(
                        value = biologyText,
                        onValueChange = { if (it.length <= 3) biologyText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Bio (/360)") },
                        placeholder = { Text("320") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_mock_biology"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEspresso,
                            unfocusedBorderColor = CremeOutline
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mistake Breakdown in Test
                Text("Errors in this Mock Test", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EspressoText)
                Text("Track marks lost to careless mistakes vs conceptual gaps:", fontSize = 11.sp, color = StoneSubtext)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = carelessText,
                        onValueChange = { if (it.length <= 2) carelessText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Careless Slips") },
                        placeholder = { Text("e.g. 4") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_mock_careless"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEspresso,
                            unfocusedBorderColor = CremeOutline
                        ),
                        supportingText = { Text("-5 marks each", fontSize = 10.sp, color = StoneSubtext) }
                    )

                    OutlinedTextField(
                        value = conceptualText,
                        onValueChange = { if (it.length <= 2) conceptualText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Conceptual Gaps") },
                        placeholder = { Text("e.g. 5") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_mock_conceptual"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryEspresso,
                            unfocusedBorderColor = CremeOutline
                        ),
                        supportingText = { Text("Theory to revise", fontSize = 10.sp, color = StoneSubtext) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Test Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Test Analysis & Reflections (optional)") },
                    placeholder = { Text("e.g. Rushed in physics kinematics; biology was strong...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(85.dp)
                        .testTag("input_mock_notes"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryEspresso,
                        unfocusedBorderColor = CremeOutline
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        showError = true
                        return@Button
                    }
                    onSaveTest(
                        title.trim(),
                        physicsScore,
                        chemistryScore,
                        biologyScore,
                        carelessCount,
                        conceptualCount,
                        notes.trim()
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryEspresso,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("button_save_mock_test")
            ) {
                Text("Save Mock Result", fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StoneSubtext)
            }
        }
    )
}
